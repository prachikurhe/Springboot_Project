import React from 'react'

const Hello = () => {
  return (
    <div>Hello From my first react application.</div>
  )
}

export default Hello
import React from 'react'
import { BounceLoader } from 'react-spinners'

const CircleSpinner = () => {
  return (
    <div>
        <BounceLoader />
    </div>
  )
}

export default CircleSpinner
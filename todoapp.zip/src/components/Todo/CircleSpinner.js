import React from 'react'

const CircleSpinner = () => {
  return (
    <div> </div>
  )
}

export default CircleSpinner
import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'


const Logout = (props) => {
  useEffect(()=>{
    props.logout();
  },[])  
  return (
    <div>Hello you have been successfully logged out of the application. <Link to="/login">click here to login</Link></div>
  )
}

export default Logout
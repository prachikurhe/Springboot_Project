import React, { useState } from 'react'
import { Button, Container, Form, Label, FormGroup, Input , Alert } from 'reactstrap';
import { useNavigate } from 'react-router-dom';



const Login = (props) => {
  const [user, setUser] = useState({ username: 'prachi', password: '123' })
  const [loginSuccess, setLoginSuccess] = useState(true);
  const navigate = useNavigate();
  const onChangeHandler = (event) => {
    setUser({ ...user, [event.target.name]: event.target.value })

  }

  const clickHandler = (e) => {
    e.preventDefault();
    if (user.username === 'prachi' && user.password === '123'){
      setLoginSuccess(true)
      props.login(user.username);
      navigate("/welcome", {state:{user:user.username}})
    }
    else{

      setLoginSuccess(false)
      setTimeout(()=>{
        setLoginSuccess(true)
      },3000)
    }
      
  }
  return (
    <Container style={{ marginTop: '20px', width: '50%' }}>
      
      {!loginSuccess && <Alert color="danger">
          Login failure please try again
      </Alert>}
      <Form>
        <FormGroup>
          <Label for="username">
            Username
          </Label>
          <Input
            id="username"
            name="username"
            placeholder="enter your name"
            type="text"
            onChange={onChangeHandler}
          />
        </FormGroup>
        <FormGroup>
          <Label for="password">
            Password
          </Label>
          <Input
            id="password"
            name="password"
            placeholder="enter your password"
            type="password"
            onChange={onChangeHandler}
          />
        </FormGroup>
        <Button color="success" onClick={clickHandler} >
          Login
        </Button>
      </Form>
    </Container>
  )
}

export default Login
import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import AuthenticationService from '../../service/AuthenticationService';

const Protected = (props) => {
  const navigate=useNavigate();
  useEffect(()=>{
      console.log('use effect  from protected route');
      if(!AuthenticationService.isLoggedIn()){
        console.log('the user is not logged in redirecting to the login page')
        navigate("/login")
      }
  },[])
  const {Component}=props
  return (
    <div>
        <Component />
    </div>
  )
}

export default Protected
import moment from 'moment';
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Button, Container, Form, Label, FormGroup, Input, FormFeedback } from 'reactstrap';
import CircleSpinner from '../CircleSpinner';


const UpdateTodo = () => {
  const location = useLocation();
  const [todo, setTodo] = useState({})
  const [error, setError] = useState({
    errors: {},
    isError: false
  })
  const [loading ,setLoading]=useState(false)
  const navigate = useNavigate()
  const onChangeHandler = (e) => {
    setTodo({ ...todo, [e.target.name]: e.target.value })
  }

  const updateHandler = async (e) => {
    setLoading(true)
    e.preventDefault();
    const requestOptions = {
      'method': 'PUT',
      'body': JSON.stringify({ name: todo.name, description: todo.description, completionDate: todo.completionDate, done: todo.done }),
      'headers': { 'Content-type': 'application/json;charset=UTF-8' }
    }
    const data = await fetch(`http://localhost:8082/api/v1/todo/${todo.id}`, requestOptions);
    if (data.status === 500) {
        console.log('some problem with validation')
        const errorData=await data.json()
        console.log(errorData)
        setError({isError:true, errors:errorData})

    } else {
      const parsedData = await data.json()

      console.log('the parsed data is ' + parsedData);
      navigate('/todos')

    }
    setLoading(false)

  }
  useEffect(() => {
    console.log('the update component has been called');
    const d = moment(location.state.todo.completionDate).format('YYYY-MM-DD')
    console.log(d)
    console.log(location.state.todo)

    setTodo({ ...location.state.todo, completionDate: d })
  }, [])
  return (
    <Container style={{ marginTop: '20px', width: '50%' }}>
      {loading && <CircleSpinner />}

      {!loading && <Form>
        <FormGroup>
          <Label for="name">
            Name
          </Label>
          <Input 
            id="name"
            name="name"
            type="text"
            value={todo.name}
            onChange={onChangeHandler}
            invalid={'name' in error.errors}
            
          />
          <FormFeedback>{error.errors.name}</FormFeedback>
        </FormGroup>
        <FormGroup>
          <Label for="description">
            Description
          </Label>
          <Input
            id="description"
            name="description"
            type="text"
            value={todo.description}
            onChange={onChangeHandler}
            invalid={'description' in error.errors}
          />
          <FormFeedback>{error.errors.description}</FormFeedback>
        </FormGroup>
        <FormGroup>
          <Label for="done">
            isDone
          </Label>
          <Input
            id="done"
            name="done"
            type="checkbox"
            checked={todo.done}
            value={todo.done}
            onChange={onChangeHandler}
          />
        </FormGroup>
        <FormGroup>
          <Label for="completionDate">
            Completion Date
          </Label>
          <Input
            id="completionDate"
            name="completionDate"
            type="date"
            value={todo.completionDate}
            onChange={onChangeHandler}
          />
        </FormGroup>
        <Button color="success" onClick={updateHandler} >
          Update
        </Button>
      </Form>}
    </Container>
  )
}

export default UpdateTodo